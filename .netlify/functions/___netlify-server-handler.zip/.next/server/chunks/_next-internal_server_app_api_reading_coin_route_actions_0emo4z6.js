module.exports=[88705,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_reading_coin_route_actions_0emo4z6.js.map