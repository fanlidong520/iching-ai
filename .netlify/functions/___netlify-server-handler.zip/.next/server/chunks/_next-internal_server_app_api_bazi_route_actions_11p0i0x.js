module.exports=[87436,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_bazi_route_actions_11p0i0x.js.map