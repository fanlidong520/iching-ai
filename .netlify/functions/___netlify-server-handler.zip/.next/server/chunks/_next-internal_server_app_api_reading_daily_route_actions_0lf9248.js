module.exports=[62776,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_reading_daily_route_actions_0lf9248.js.map