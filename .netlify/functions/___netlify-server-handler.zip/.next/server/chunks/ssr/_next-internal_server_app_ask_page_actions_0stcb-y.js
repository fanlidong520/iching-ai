module.exports=[86418,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_ask_page_actions_0stcb-y.js.map