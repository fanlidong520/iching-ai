module.exports=[39875,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_monthly_page_actions_08s3f_0.js.map