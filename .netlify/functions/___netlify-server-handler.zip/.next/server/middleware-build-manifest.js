globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/03~yq9q893hmn.js"
  ],
  "lowPriorityFiles": [
    "static/nvLMZTI5oNZehUozPNJAz/_buildManifest.js",
    "static/nvLMZTI5oNZehUozPNJAz/_ssgManifest.js",
    "static/nvLMZTI5oNZehUozPNJAz/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/0yb2wil16uz6h.js",
    "static/chunks/0p-46mwv82lcw.js",
    "static/chunks/0n1bpogj.il~n.js",
    "static/chunks/10u3y4bw1ayzs.js",
    "static/chunks/0pqt~8bl3ukh4.js",
    "static/chunks/turbopack-17ixhy306g3_a.js"
  ]
};
