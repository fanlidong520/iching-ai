var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/reading/daily/route.js")
R.c("server/chunks/[root-of-the-server]__0.67jqx._.js")
R.c("server/chunks/[root-of-the-server]__0j8-xkl._.js")
R.c("server/chunks/src_lib_deepseek_ts_0a62xih._.js")
R.c("server/chunks/_next-internal_server_app_api_reading_daily_route_actions_0lf9248.js")
R.m(23297)
module.exports=R.m(23297).exports
