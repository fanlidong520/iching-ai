var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/reading/coin/route.js")
R.c("server/chunks/[root-of-the-server]__0mdnert._.js")
R.c("server/chunks/[root-of-the-server]__0j8-xkl._.js")
R.c("server/chunks/src_lib_deepseek_ts_0a62xih._.js")
R.c("server/chunks/_next-internal_server_app_api_reading_coin_route_actions_0emo4z6.js")
R.m(17972)
module.exports=R.m(17972).exports
