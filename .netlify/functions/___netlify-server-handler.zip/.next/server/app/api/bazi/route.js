var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/bazi/route.js")
R.c("server/chunks/[root-of-the-server]__0y1nlp_._.js")
R.c("server/chunks/[root-of-the-server]__0j8-xkl._.js")
R.c("server/chunks/src_lib_deepseek_ts_0a62xih._.js")
R.c("server/chunks/_next-internal_server_app_api_bazi_route_actions_11p0i0x.js")
R.m(41082)
module.exports=R.m(41082).exports
